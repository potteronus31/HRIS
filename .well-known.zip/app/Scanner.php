<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scanner extends Model
{
    //
}
