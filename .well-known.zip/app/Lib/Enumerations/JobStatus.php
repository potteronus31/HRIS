<?php
namespace App\Lib\Enumerations;

class JobStatus
{
    public static $Apply = 0;
    public static $SHORTLIST = 1;
    public static $REJECT = 2;
    public static $CALL_FOR_INTERVIEW = 3;
}