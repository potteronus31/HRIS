<?php
namespace App\Lib\Enumerations;

class LeaveStatus
{
     public static $PENDING  = 1;
     public static $APPROVE  = 2;
     public static $REJECT  = 3;
}