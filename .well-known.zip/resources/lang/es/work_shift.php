<?php 

return [

    'work_shift_list' => 'Lista de turnos de trabajo',
    'add_work_shift' => 'Agregar turno de trabajo',
    'work_shift_name' => 'Nombre del turno de trabajo',
    'start_time' => 'Hora de inicio',
    'end_time' => 'Hora de finalización',
    'late_count_time' => 'Tiempo de cuenta tardía',
    'edit_work_shift' => 'Editar turno de trabajo',
    'view_work_shift' => 'Ver turno de trabajo',
];