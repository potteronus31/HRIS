<?php 

return [

    'pay_grade_list' => 'Lista de calificaciones de pago',
    'pay_grade_name' => 'Nombre de grado de pago',
    'gross_salary' => 'Salario bruto',
    'percentage_of_basic' => 'Porcentaje de básico',
    'percentage_of_basic' => 'Porcentaje de básico',
    'basic_salary' => 'Salario base',
    'over_time_rate' => 'Tasa de horas extra',
    'add_pay_grade' => 'Agregar calificación de pago',
    'edit_pay_grade' => 'Editar grado de pago',
    'view_pay_grade' => 'Ver grado de pago',
    'allowance' => 'Tolerancia',
    'deduction' => 'Deducción',
    'per_hour' => 'Por hora',
    'hourly_pay_grade_list' => 'Lista de calificaciones de pago por hora',
    'hourly_grade' => 'Calificación por hora',
    'hourly_rate' => 'Tarifa por hora',
    'add_hourly_pay_grade' => 'Agregar calificación de pago por hora',
    'edit_hourly_pay_grade' => 'Editar calificación de pago por hora',
    'view_hourly_pay_grade' => 'Ver calificación de pago por hora',
    'hourly_pa_grade_name' => 'Nombre de grado de pago por hora',

    

];