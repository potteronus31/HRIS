<?php

return [

    'branch_list' => 'Lista de sucursales',
    'branch_name' => 'Nombre de la sucursal',
    'add_branch' => 'Agregar rama',
    'view_branch' => 'Ver sucursal',
    'edit_branch' => 'Editar sucursal',

];
