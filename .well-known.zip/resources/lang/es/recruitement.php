<?php 


return [
  
 
    'job_post_list' => 'Lista de puestos de trabajo',
    'create_new_job_post' => 'Crear nuevo puesto de trabajo',
    'view_job_post' => 'Ver puesto de trabajo',
    'edit_job_post' => 'Editar publicación de trabajo',
    'job_title' => 'Título profesional',
    'publish_by' => 'Publicar por',
    'application_end_date' => 'Fecha de finalización de la solicitud',
    'description' => 'Descripción',
    'job_publish_date' => 'Fecha de publicación del trabajo',
    'published' => 'Publicada',
    'unpublished' => 'Inédita',
    'job_application' => 'Aplicacion de trabajo',
    'job_candidate_list' => 'Lista de candidatos de trabajo',
    'short_listed_application' => 'Solicitud listada',
    'reject_application' => 'Rechazar solicitud',
    'job_interview' => 'Entrevista de trabajo',

    // added new 

    'job_post' => 'Job Post',
];