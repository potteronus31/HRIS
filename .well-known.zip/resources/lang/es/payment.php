<?php 

return [

    'payment_history' => 'historial de pagos',
    'all_payment_history' => 'Todo el historial de pagos',
    'all_payment_history' => 'Todo el historial de pagos',
    'enter_month' => 'Ingrese mes',
    
    //  refere from salary_sheet

    'to_be_paid' => 'a pagar',
    'total' => 'total',
    'my_payroll' => 'mi nómina',
];