<?php

// role and premission related 

return [
 
    'add_role' => 'Agregar rol',
    'edit_role' => 'Editar rol',
    'role_list' => 'Lista de roles',
    'role_list' => 'Lista de roles',
    'name' => 'Nombre',
    'view_role' => 'Ver rol',
    'role_name' => 'Nombre de rol',
    'add_role_permission' => 'Agregar permiso de rol',
    'role_permission' => 'Permiso de rol',
    'page_permission' => 'Permiso de páginas',
    'select_all' => 'Seleccionar todo',
    'user_role' => 'Rol del usuario',

];