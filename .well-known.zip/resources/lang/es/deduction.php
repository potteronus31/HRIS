<?php

return [

    'deduction_list' => 'lista de deducciones',
    'deduction_name' => 'nombre de deducción',
    'deduction_type' => 'tipo de deducción',
    'percentage_of_basic' => 'porcentaje de básico',
    'limit_per_month' => 'límite por mes',
    'add_deduction' => 'agregar deducción',
    'edit_deduction' => 'editar deducción',
    'view_deduction' => 'ver deducción',


];