<?php 


return [
 
 'termination_list' => 'Lista de terminación',
 'add_new_termination' => 'Agregar nueva terminación',
 'employee_name' => 'Nombre de empleado',
 'subject' => 'Tema',
 'termination_type' => 'Tipo de terminación',
 'notice_date' => 'Fecha de notificacion',
 'termination_date' => 'Fecha de conclusión',
 'terminated_by' => 'Terminado por',
 'termination_list' => 'Lista de terminación',
 'view_termination' => 'Ver terminación',
 'view_termination' => 'Ver terminación',
 'description' => 'Descripción',

];


