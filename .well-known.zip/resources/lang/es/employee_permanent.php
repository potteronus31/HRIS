<?php 

return [

    'employee_permanent' => 'Empleado permanente',
    'update_status' => 'Estado de actualización',
    'probation_period' => 'Período de prueba',
    'permanent' => 'Permanente',


];

?>