<?php 

return [
 
    'bonus_setting' => 'Bonus Setting',
    'festival_name' => 'Festival Name',
    'percentage_of_bonus' => 'Percentage of Bonus',
    'add_new_bonus' => 'Add New Bonus',
    'edit_bonus' => 'Edit Bonus',
    'view_bonus' => 'View Bonus',
    'bonus_type' => 'Bonus_type',
    'tax' => 'Tax',
    'bonus_amount' => 'Bonus Amount',
    'generate_bonus' => 'Generate Bonus',
    'view_bonus_list' => 'View Bonus List',

    
    // newly added 

    'bonus_list' => 'lista de bonificación',
    'net_bonus' => 'bonificación neta',
    'total_bonus' => 'bonificación total',


];