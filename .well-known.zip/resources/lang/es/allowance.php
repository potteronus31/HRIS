<?php 


return [
 
    'allowance_list' => 'Lista de asignaciones',
    'allowance_name' => 'Nombre de asignación',
    'allowance_type' => 'Tipo de asignación',
    'percentage_of_basic' => 'Porcentaje de básico',
    'limit_per_month' => 'Límite por mes',
    'add_allowance' => 'Agregar asignación',
    'edit_allowance' => 'Editar asignación',
    'view_allowance' => 'Ver asignación',

];