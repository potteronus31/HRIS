<?php 

return [

    'award_list' => 'Lista de premios',
    'award_name' => 'Nombre del premio',
    'gift_item' => 'Artículo de regalo',
    'add_new_award' => 'Añadir nuevo premio',
    'edi_award' => 'Editar premio',
    'view_award' => 'Ver premio',
];