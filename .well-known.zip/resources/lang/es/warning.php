<?php

return [

    'warning_list' => 'Lista de advertencia',
    'warning' => 'Advertencia',
    'employee_name' => 'Nombre de empleado',
    'warning_date' => 'Fecha de advertencia',
    'subject' => 'tema',
    'warning_type' => 'Tipo de advertencia',
    'warning_by' => 'Advertencia por',
    'add_warning' => 'Agregar advertencia',
    'view_warning' => 'Ver advertencia',
    'edit_warning' => 'Editar advertencia',
    'description' => 'Descripción',

];
