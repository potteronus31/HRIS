<?php 

return [

    'training_type_list' => 'Lista de tipos de entrenamiento',
    'training_type_name' => 'Nombre del tipo de entrenamiento',
    'add_training_type' => 'Agregar tipo de entrenamiento',
    'edit_training_type' => 'Editar tipo de entrenamiento',
    'view_training_type' => 'Ver tipo de entrenamiento',
    'employee_training_list' => 'Lista de entrenamiento de empleados',
    'training_type' => 'Tipo de entrenamiento',
    'subject' => 'Tema',
    'training_duration' => 'Duración del entrenamiento',
    'add_employee_training' => 'Agregar capacitación de empleados',
    'edit_employee_training' => 'Editar capacitación de empleados',
    'view_employee_training' => 'Ver capacitación de empleados',
    'certificate' => 'Certificado',
    'description' => 'Descripción',
    'employee_training_report' => 'Informe de capacitación de empleados',

];