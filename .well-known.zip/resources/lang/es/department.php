<?php 

return [

  'department_list' => 'Lista de departamentos',
  'department_name' => 'Nombre de Departamento',
  'action' => 'Acción',
  'add_department' => 'Agregar departamento',
  'view_department' => 'Ver departamento',
  'edit_department' => 'Editar departamento',

];