<?php 


return [
 
    'tax_rule_setup' => 'Configuración de la regla de impuestos',
    'rate_of_income_tax' => 'Tasa de impuesto sobre la renta',
    'total_income' => 'Ingresos totales',
    'tax_rules' => 'Reglas de impuestos',
    'male' => 'Masculino',
    'female' => 'Hembra',
    'remaining_total_income' => 'Ingresos totales restantes',
    'remaining_taxable_amount' => 'Importe imponible restante',
    'first' => 'Primera',
    'next' => 'Próxima',
    'salary_deduction_for_late_attendance' => 'Deducción salarial por asistencia tardía',
    'rules_for_salary_deduction' => ' Reglas de deducción salarial',
    'for_days' => ' Por dias',
    'day_oF_salary_deduction' => 'Día de deducción salarial',


     // newly added 

     'tax_rate' => 'tasa de impuesto',
     'taxable_amount' => 'base imponible',

];