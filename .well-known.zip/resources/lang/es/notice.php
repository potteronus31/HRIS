<?php 

return [

    'notice_list' => 'Lista de avisos',
    'notice_name' => 'Nombre del aviso',
    'title' => 'Título',
    'publish_date' => 'Fecha de publicación',

    'published_by' => 'Publicar por',
    
    'attach_file' => 'Adjuntar archivo',
    'description' => 'Descripción',
    'add_new_notice' => 'Agregar nuevo aviso',
    'edi_notice' => 'Editar aviso',
    'view_notice' => 'Ver aviso',
];