<?php 


return [

    'holiday_list' => 'Lista de vacaciones',
    'add_holiday' => 'Agregar vacaciones',
    'view_holiday' => 'Ver vacaciones',
    'edit_holiday' => 'Editar vacaciones',
    'holiday_name' => 'Nombre del día santo',
    'name' => 'Nombre',
    'public_holiday_list' => 'Lista de días festivos',
    'add_public_holiday' => 'Agregar días festivos',
    'view_public_holiday' => 'Ver días festivos',
    'edit_public_holiday' => 'Editar días festivos',
    'weekly_holiday_list' => 'Lista de vacaciones semanales',
    'add_weekly_holiday' => 'Agregar vacaciones semanales',
    'view_weekly_holiday' => 'Ver vacaciones semanales',
    'edit_weekly_holiday' => 'Editar vacaciones semanales',
    'start_date' => 'Fecha de inicio',
    'end_date' => 'Fecha final',
    'comment' => 'Comentario',

];