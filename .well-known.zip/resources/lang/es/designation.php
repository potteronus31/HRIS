<?php

return [

    'designation_list' => 'Lista de designaciones',
    'designation_name' => 'Nombre de designación',
    'add_designation' => 'Agregar designación',
    'view_designation' => 'Ver designación',
    'edit_designation' => 'Esu designación',

];
