<?php 


return [
 
 'employee_promotion_list' => 'Lista de promoción de empleados',
 'add_employee_promotion' => 'Agregar promoción de empleado',
 'employee_name' => 'Nombre de empleado',
 'promotion_date' => 'Fecha de promoción',
 'promoted_department' => 'Departamento promocionado',
 'promoted_designation' => 'Designación promovida',
 'promoted_paygrade' => 'Grado de pago promocionado',
 'promoted_salary' => 'Salario promocionado',
 'view_employee_promotion' => 'Ver promoción de empleados',
 'current_department' => 'Departamento actual',
 'current_designation' => 'designación actual',
 'current_paygrade' => 'Grado de pago actual',
 'current_salary' => 'Salario actual',
 'details' => 'Detalles',
 
]
