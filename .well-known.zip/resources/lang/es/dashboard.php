<?php 


 return [
   
     'dashboard' => 'Tablero',
     'total_employee' => 'Empleado total',
     'total_department' => 'Departamento',
     'total_present' => 'presente',
     'total_absent' => 'ausente',
     'today_attendance' => 'Asistencia hoy',
     'photo' => 'Foto',
     'in_time' => 'A tiempo',
     'out_time' => 'Fuera de tiempo',
     'late' => 'Tarde',
     'upcoming_birthday' => 'Cumpleaños próximo',

     // completed till now 

     'recent_leave_application' => 'Solicitud de licencia reciente',
     'notice_board' => 'Tablón de anuncios',
     


  
 ];


?>