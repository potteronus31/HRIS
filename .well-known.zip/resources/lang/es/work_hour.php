<?php

return 
[
    'employee_work_hour' => 'Hora de trabajo del empleado',
    'total_working_hour' => 'Hora total de trabajo',
    'approve_hour' => 'Aprobar hora',
    'approve_minutes' => 'Aprobar actas',

];