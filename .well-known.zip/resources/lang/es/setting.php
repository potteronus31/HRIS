<?php 

return [
    'general_settings' => 'Configuración general',
    'company_addrees_settings' => 'configuración de dirección de la empresa',
    'print_head_settings' => 'Configuración del cabezal de impresión',
];