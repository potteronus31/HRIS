<?php 


return [

    'holiday_list' => 'Liste de vacances',
    'add_holiday' => 'Ajouter des vacances',
    'view_holiday' => 'Voir les vacances',
    'edit_holiday' => 'Modifier les vacances',
    'holiday_name' => 'Nom du jour saint',
    'name' => 'prénom',
    'public_holiday_list' => 'Liste des jours fériés',
    'add_public_holiday' => 'Ajouter un jour férié',
    'view_public_holiday' => 'Voir les jours fériés',
    'edit_public_holiday' => 'Modifier les jours fériés',
    'weekly_holiday_list' => 'Liste de vacances hebdomadaire',
    'add_weekly_holiday' => 'Ajouter des vacances hebdomadaires',
    'view_weekly_holiday' => 'Voir les vacances hebdomadaires',
    'edit_weekly_holiday' => 'Modifier les vacances hebdomadaires',
    'start_date' => 'Date de début',
    'end_date' => 'Date de fin',
    'comment' => 'Commentaire',

];