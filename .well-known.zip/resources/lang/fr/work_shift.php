<?php 

return [

    'work_shift_list' => 'Liste des quarts de travail',
    'add_work_shift' => 'Ajouter un quart de travail',
    'work_shift_name' => 'Nom du quart de travail',
    'start_time' => 'Heure de début',
    'end_time' => 'Heure de fin',
    'late_count_time' => 'Temps de comptage tardif',
    'edit_work_shift' => 'Modifier le quart de travail',
    'view_work_shift' => 'Afficher le quart de travail',
];