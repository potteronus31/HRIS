<?php 

return [

    'pay_grade_list' => 'Liste des notes de paie',
    'pay_grade_name' => 'Nom du grade de rémunération',
    'gross_salary' => 'Salaire brut',
    'percentage_of_basic' => 'Pourcentage de base',
    'percentage_of_basic' => 'Pourcentage de base',
    'basic_salary' => 'Salaire de base',
    'over_time_rate' => 'Taux d heure supplémentaire',
    'add_pay_grade' => 'Ajouter une note de salaire',
    'edit_pay_grade' => 'Modifier la note de paie',
    'view_pay_grade' => 'Afficher la note de paie',
    'allowance' => 'Allocation',
    'deduction' => 'Déduction',
    'per_hour' => 'Par heure',
    'hourly_pay_grade_list' => 'Liste de rémunération horaire',
    'hourly_grade' => 'Niveau horaire',
    'hourly_rate' => 'Taux horaire',
    'add_hourly_pay_grade' => 'Ajouter une rémunération horaire',
    'edit_hourly_pay_grade' => 'Modifier le salaire horaire',
    'view_hourly_pay_grade' => 'Afficher le salaire horaire',
    'hourly_pa_grade_name' => 'Nom du salaire horaire',

    

];