<?php 

return [
    'general_settings' => 'réglages généraux',
    'company_addrees_settings' => 'paramètres d adresse de l entreprise',
    'print_head_settings' => 'Paramètres de la tête d impression',
]