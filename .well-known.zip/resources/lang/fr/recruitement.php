<?php 


return [
  
 
    'job_post_list' => 'Liste des offres d emploi',
    'create_new_job_post' => 'Créer une nouvelle offre d emploi',
    'view_job_post' => 'Voir l offre d emploi',
    'edit_job_post' => 'Modifier l offre d emploi',
    'job_title' => 'Profession',
    'pulish_by' => 'Publier par',
    'application_end_date' => 'Date de fin de candidature',
    'description' => 'La description',
    'job_publish_date' => 'Date de publication du travail',
    'published' => 'Publié',
    'unpublished' => 'Non publié',
    'job_application' => 'Demande d emploi',
    'job_candidate_list' => 'Liste des candidats',
    'short_listed_application' => 'Application présélectionnée',
    'reject_application' => 'Rejeter la demande',
    'job_interview' => 'Entretien d embauche',
];