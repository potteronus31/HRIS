<?php 


return [
 
    'tax_rule_setup' => 'Configuration des règles fiscales',
    'rate_of_income_tax' => 'Taux d impôt sur le revenu',
    'total_income' => 'Revenu total',
    'tax_rules' => 'Règles fiscales',
    'male' => 'Mâle',
    'female' => 'Femme',
    'remaining_total_income' => 'Revenu total restant',
    'remaining_taxable_amount' => 'Montant imposable restant',
    'first' => 'Première',
    'next' => 'Prochain',
    'salary_deduction_for_late_attendance' => 'Déduction salariale pour participation tardive',
    'rules_for_salary_deduction' => ' Règles de retenue sur salaire',
    'for_days' => ' Pendant des jours',
    'day_oF_salary_deduction' => 'Jour de retenue sur salaire',

];