<?php 

return [

    'award_list' => 'Liste de prix',
    'award_name' => 'Nom du prix',
    'gift_item' => 'Article cadeau',
    'add_new_award' => 'Ajouter un nouveau prix',
    'edi_award' => 'Editer le prix',
    'view_award' => 'Voir le prix',
];