<?php

return [

    'branch_list' => 'Liste de branche',
    'branch_name' => 'Nom de la filiale',
    'add_branch' => 'Ajouter une branche',
    'view_branch' => 'Voir la branche',
    'edit_branch' => 'Modifier la branche',

];
