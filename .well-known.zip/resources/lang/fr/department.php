<?php 

return [

  'department_list' => 'Liste des départements',
  'department_name' => 'Nom du département',
  'action' => 'action',
  'add_department' => 'Ajouter un département',
  'view_department' => 'Voir le département',
  'edit_department' => 'Modifier le département',

];