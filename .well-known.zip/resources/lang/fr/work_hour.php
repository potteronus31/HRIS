<?php

return 
[
    'employee_work_hour' => 'Heure de travail des employés',
    'total_working_hour' => 'Durée totale de travail',
    'approve_hour' => 'Approuver l heure',
    'approve_minutes' => 'Approuver le procès-verbal',

];