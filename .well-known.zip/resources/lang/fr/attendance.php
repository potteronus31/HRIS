<?php 
 

  return [

    'daily_attendance' => 'Présence quotidienne',
    'date' => 'Rendez-vous amoureux',
    'in_time' => "À l'heure",
    'out_time' => "Temps de sortie",
    'working_time' => 'Temps de travail',
    'late' => 'En retard',
    'late_time' => 'Heure tardive',
    'over_time' => 'Heures supplémentaires',
    'my_attendance_report' => 'Mon rapport de présence',
    'total_working_days' => 'Nombre total de jours ouvrables',
    'total_present' => 'Total présent',
    'total_absence' => 'Absence Totale',
    'total_leave' => 'Total des congés',
    'total_late' => 'Total en retard',
    'expected_working_hour' => 'Heure de travail prévue',
    'actual_working_hour' => 'Heure de travail réelle',
    'over_time' => 'Heures supplémentaires',
    'deficiency' => 'Carence',
    'attendance_summary_report' => 'Rapport sommaire de présence',
    'day_of_worked' => 'Jour de congé travaillé',
    'gov_day_work' => 'Jour de travail',
    'earn_leave' => 'Gagner des congés',
    'employee_attendance' => 'Présence des employés',
    'department' => 'département',

  ]

?>