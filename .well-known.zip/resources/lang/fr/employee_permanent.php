<?php 

return [

    'employee_permanent' => 'Employé Permanent',
    'update_status' => 'État de mise à jour',
    'probation_period' => 'Période de probation',
    'permanent' => 'Permanente',


];

?>