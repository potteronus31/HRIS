<?php 

return [

    'training_type_list' => 'Liste des types de formation',
    'training_type_name' => 'Nom du type de formation',
    'add_training_type' => 'Ajouter un type de formation',
    'edit_training_type' => 'Modifier le type de formation',
    'view_training_type' => 'Afficher le type de formation',
    'employee_training_list' => 'Liste de formation des employés',
    'training_type' => 'Type de formation',
    'subject' => 'Assujettir',
    'training_duration' => 'Durée de la formation',
    'add_employee_training' => 'Ajouter une formation aux employés',
    'edit_employee_training' => 'Modifier la formation des employés',
    'view_employee_training' => 'Voir la formation des employés',
    'certificate' => 'Certificat',
    'description' => 'La description',
    'employee_training_report' => 'Rapport de formation des employés',

];