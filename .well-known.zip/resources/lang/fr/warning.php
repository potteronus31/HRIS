<?php

return [

    'warning_list' => 'Liste d avertissement',
    'warning' => 'Attention',
    'employee_name' => 'Nom de l employé',
    'warning_date' => 'Date d avertissement',
    'subject' => 'assujettir',
    'warning_type' => 'Type d avertissement',
    'warning_by' => 'Avertissement par',
    'add_warning' => 'Ajouter un avertissement',
    'view_warning' => 'Afficher l avertissement',
    'edit_warning' => 'Modifier l avertissement',
    'description' => 'La description',

];
