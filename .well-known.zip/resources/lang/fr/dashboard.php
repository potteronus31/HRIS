<?php 


 return [
   
     'dashboard' => 'Tableau de bord',
     'total_employee' => 'Total employé',
     'total_department' => 'département',
     'total_present' => 'Présent',
     'total_absent' => 'absente',
     'today_attendance' => "Participation aujourd'hui",
     'photo' => 'Photo',
     'in_time' => "À l'heure",
     'out_time' => 'Temps de sortie',
     'late' => 'En retard',
     'upcoming_birthday' => 'Anniversaire à venir',

     // completed till now 

     'recent_leave_application' => 'Demande de congé récente',
     'notice_board' => "Tableau d'affichage",
     


  
 ];


?>