<?php 

return [
 
    'bonus_setting' => 'Réglage Bonus',
    'festival_name' => 'Nom du festival',
    'percentage_of_bonus' => 'Pourcentage du bonus',
    'add_new_bonus' => 'Ajouter un nouveau bonus',
    'edit_bonus' => 'Modifier le bonus',
    'view_bonus' => 'Voir le bonus',
    'bonus_type' => 'Type de bonus',
    'tax' => 'Impôt',
    'bonus_amount' => 'Montant du bonus',
    'generate_bonus' => 'Générer des bonus',
    'view_bonus_list' => 'Voir la liste des bonus',


]