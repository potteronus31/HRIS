<?php 

return [

    'payment_history' => 'historique de paiement',
    'all_payment_history' => 'Tout l historique des paiements',
    'all_payment_history' => 'Tout l historique des paiements',
    'enter_month' => 'Entrez le mois',
    
    //  refere from salary_sheet
]