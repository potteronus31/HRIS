<?php 


return [
 
 'termination_list' => 'Liste de résiliation',
 'add_new_termination' => 'Ajouter une nouvelle résiliation',
 'employee_name' => 'Nom de lemployé',
 'subject' => 'Assujettir',
 'termination_type' => 'Type de résiliation',
 'notice_date' => 'Date d avis',
 'termination_date' => 'Date de résiliation',
 'terminated_by' => 'Résilié par',
 'termination_list' => 'Liste de résiliation',
 'view_termination' => 'Afficher la résiliation',
 'view_termination' => 'Afficher la résiliation',
 'description' => 'La description',

]


