<?php 


return [
 
    'allowance_list' => "Liste d'allocation",
    'allowance_name' => "Nom d'allocation",
    'allowance_type' => "Type d'allocation",
    'percentage_of_basic' => "Pourcentage de base",
    'limit_per_month' => "Limite par mois",
    'add_allowance' => "Ajouter une allocation",
    'edit_allowance' => "Modifier l'allocation",
    'view_allowance' => "Allocation de vue",

];