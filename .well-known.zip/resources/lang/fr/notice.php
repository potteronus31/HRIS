<?php 

return [

    'notice_list' => 'Liste des avis',
    'notice_name' => 'nom de l avis',
    'title' => 'Titre',
    'publish_date' => 'Date de publication',

    'published_by' => 'Publier par',
    
    'attach_file' => 'Pièce jointe',
    'description' => 'La description',
    'add_new_notice' => 'Ajouter un nouvel avis',
    'edi_notice' => 'Modifier l avis',
    'view_notice' => 'Afficher l avis',
];