<?php 


return [
 
 'employee_promotion_list' => 'Liste de promotion des employés',
 'add_employee_promotion' => 'Ajouter une promotion aux employés',
 'employee_name' => 'Nom de l employé',
 'promotion_date' => 'Date de la promotion',
 'promoted_department' => 'Département promu',
 'promoted_designation' => 'Désignation promue',
 'promoted_paygrade' => 'Niveau de rémunération promu',
 'promoted_salary' => 'Salaire promu',
 'view_employee_promotion' => 'Voir la promotion des employés',
 'current_department' => 'Département actuel',
 'current_designation' => 'désignation actuelle',
 'current_paygrade' => 'Niveau de rémunération actuel',
 'current_salary' => 'Salaire actuel',
 'details' => 'Détails',
 
]
