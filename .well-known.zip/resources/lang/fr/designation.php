<?php

return [

    'designation_list' => 'Liste de désignation',
    'designation_name' => 'Nom de désignation',
    'add_designation' => 'Ajouter une désignation',
    'view_designation' => 'Voir la désignation',
    'edit_designation' => 'Modifier la désignation',

];
