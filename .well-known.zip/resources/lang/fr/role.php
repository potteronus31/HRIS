<?php

// role and premission related 

return [
 
    'add_role' => 'Ajouter un rôle',
    'edit_role' => 'Modifier le rôle',
    'role_list' => 'Liste des rôles',
    'role_list' => 'Liste des rôles',
    'name' => 'prénom',
    'view_role' => 'Afficher le rôle',
    'role_name' => 'Nom de rôle',
    'add_role_permission' => 'Ajouter une autorisation de rôle',
    'role_permission' => 'Autorisation de rôle',
    'page_permission' => 'Permission de pages',
    'select_all' => 'Tout sélectionner',
    'user_role' => 'Rôle d utilisateur',

];