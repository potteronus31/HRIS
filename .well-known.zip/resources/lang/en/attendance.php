<?php 
 

  return [

    'daily_attendance' => 'Daily Attendance',
    'date' => 'Date',
    'in_time' => 'In Time',
    'out_time' => 'Out Time',
    'working_time' => 'Working Time',
    'late' => 'Late',
    'late_time' => 'Late Time',
    'over_time' => 'Over Time',
    'my_attendance_report' => 'My Attendance Report',
    'total_working_days' => 'Total Working days',
    'total_present' => 'Total Present',
    'total_absence' => 'Total Absence',
    'total_leave' => 'Total Leave',
    'total_late' => 'Total Late',
    'expected_working_hour' => 'Expected Working Hour',
    'actual_working_hour' => 'Actual Working Hour',
    'over_time' => 'Over Time',
    'deficiency' => 'Deficiency',
    'attendance_summary_report' => 'Attendance Summary Report',
    'day_of_worked' => 'Day off worked',
    'gov_day_work' => 'Gov. Day Worked',
    'earn_leave' => 'Earn Leave',
    'employee_attendance' => 'Employee Attendance',
    'department' => 'Department',

    // added later 

    'monthly_attendance_report' => 'Monthly Attendance Report'

  ];

?>