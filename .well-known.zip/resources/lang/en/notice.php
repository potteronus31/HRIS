<?php 

return [

    'notice_list' => 'Notice List',
    'notice_name' => 'notice Name',
    'title' => 'Title',
    'publish_date' => 'Publish Date',

    'published_by' => 'Publish By',
    
    'attach_file' => 'Attach File',
    'description' => 'Description',
    'add_new_notice' => 'Add New Notice',
    'edi_notice' => 'Edit  notice',
    'view_notice' => 'View  notice',
];