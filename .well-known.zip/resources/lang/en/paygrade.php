<?php 

return [

    'pay_grade_list' => 'Pay Grade List',
    'pay_grade_name' => 'Pay Grade Name',
    'gross_salary' => 'Gross Salary',
    'percentage_of_basic' => 'Percentage Of Basic',
    'percentage_of_basic' => 'Percentage Of Basic',
    'basic_salary' => 'Basic Salary',
    'over_time_rate' => 'Overtime Rate',
    'add_pay_grade' => 'Add Pay Grade',
    'edit_pay_grade' => 'Edit Pay Grade',
    'view_pay_grade' => 'View Pay Grade',
    'allowance' => 'Allowance',
    'deduction' => 'Deduction',
    'per_hour' => 'Per Hour',
    'hourly_pay_grade_list' => 'Hourly Pay Grade List',
    'hourly_grade' => 'Hourly Grade',
    'hourly_rate' => 'Hourly Rate',
    'add_hourly_pay_grade' => 'Add Hourly Pay Grade',
    'edit_hourly_pay_grade' => 'Edit Hourly Pay Grade',
    'view_hourly_pay_grade' => 'View Hourly Pay Grade',
    'hourly_pa_grade_name' => 'Hourly Pay Grade Name',

    

];