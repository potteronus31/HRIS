<?php 

return [
    'general_settings' => 'General Settings',
    'company_addrees_settings' => 'Company Address Setting',
    'print_head_settings' => 'Print Head Settings',
];