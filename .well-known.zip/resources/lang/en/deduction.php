<?php

return [

    'deduction_list' => 'Deduction List',
    'deduction_name' => 'Deduction Name',
    'deduction_type' => 'Deduction Type',
    'percentage_of_basic' => 'Percentage of Basic',
    'limit_per_month' => 'Limit Per Month',
    'add_deduction' => 'Add Deduction',
    'edit_deduction' => 'Edit Deduction',
    'view_deduction' => 'View Deduction',

];