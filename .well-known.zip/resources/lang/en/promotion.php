<?php 


return [
 
 'employee_promotion_list' => 'Employee Promotion List',
 'add_employee_promotion' => 'Add Employee Pormotion',
 'employee_name' => 'Employee Name',
 'promotion_date' => 'Promotion Date',
 'promoted_department' => 'Promoted Department',
 'promoted_designation' => 'Promoted Designation',
 'promoted_paygrade' => 'Promoted Pay Grade',
 'promoted_salary' => 'Promoted Salary',
 'view_employee_promotion' => 'View Employee Promotion',
 'current_department' => 'Current Department',
 'current_designation' => 'Current Designation',
 'current_paygrade' => 'Current Pay Grade',
 'current_salary' => 'Current Salary',
 'details' => 'Details',
 
];
