<?php 

return [

    'payment_history' => 'Payment History',
    'all_payment_history' => 'All Payment History',
    // 'all_payment_history' => 'All Payment History',
    'enter_month' => 'Enter Month',
    
    //  refere from salary_sheet

    'to_be_paid' => 'To be Paid',
    'total' => 'Total',
    'my_payroll' => 'My Payroll',
];