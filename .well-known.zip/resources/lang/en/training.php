<?php 

return [

    'training_type_list' => 'Training Type List',
    'training_type_name' => 'Training Type Name',
    'add_training_type' => 'Add Training Type',
    'edit_training_type' => 'Edit Training Type',
    'view_training_type' => 'View Training Type',
    'employee_training_list' => 'Employee Training List',
    'training_type' => 'Training Type',
    'subject' => 'Subject',
    'training_duration' => 'Training Duration',
    'add_employee_training' => 'Add Employee Training',
    'edit_employee_training' => 'Edit Employee Training',
    'view_employee_training' => 'View Employee Training',
    'certificate' => 'Certificate',
    'description' => 'Description',
    'employee_training_report' => 'Employee Training Report',
    'employee_training_details' => 'Employee Training Details',

];