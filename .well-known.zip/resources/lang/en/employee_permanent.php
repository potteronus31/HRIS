<?php 

return [

    'employee_permanent' => 'Employee Permanent',
    'update_status' => 'Update Status',
    'probation_period' => 'Probation Period',
    'permanent' => 'Permanent',


];

?>