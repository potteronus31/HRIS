<?php 


 return [
   
     'dashboard' => 'Dashboard',
     'total_employee' => 'Total Employee',
     'total_department' => 'Department',
     'total_present' => 'Present',
     'total_absent' => 'absent',
     'today_attendance' => 'Today Attendance',
     'photo' => 'Photo',
     'in_time' => 'In time',
     'out_time' => 'Out Time',
     'late' => 'Late',
     'upcoming_birthday' => 'Upcoming Birthday',

     // completed till now 

     'recent_leave_application' => 'Recent Leave Application',
     'notice_board' => 'Notice Board',
     


  
 ];


?>