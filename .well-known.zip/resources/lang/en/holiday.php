<?php 


return [

    'holiday_list' => 'Holiday List',
    'add_holiday' => 'Add Holiday',
    'view_holiday' => 'View Holiday',
    'edit_holiday' => 'Edit Holiday',
    'holiday_name' => 'Holy Day Name',
    'name' => 'Name',
    'public_holiday_list' => 'Public Holiday List',
    'add_public_holiday' => 'Add Public Holiday',
    'view_public_holiday' => 'View Public Holiday',
    'edit_public_holiday' => 'Edit Public Holiday',
    'weekly_holiday_list' => 'Weekly Holiday List',
    'add_weekly_holiday' => 'Add Weekly Holiday',
    'view_weekly_holiday' => 'View Weekly Holiday',
    'edit_weekly_holiday' => 'Edit Weekly Holiday',
    'start_date' => 'Start Date',
    'end_date' => 'End Date',
    'comment' => 'Comment',

];