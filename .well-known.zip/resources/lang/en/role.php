<?php

// role and premission related 

return [
 
    'add_role' => 'Add Role',
    'edit_role' => 'Edit Role',
    'role_list' => 'Role List',
    'role_list' => 'Role List',
    'name' => 'Name',
    'view_role' => 'View Role',
    'role_name' => 'Role Name',
    'add_role_permission' => 'Add Role Permission',
    'role_permission' => 'Role Permission',
    'page_permission' => 'Pages Permission',
    'select_all' => 'Select All',
    'user_role' => 'User Roll',

];