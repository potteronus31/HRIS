<?php

return [

    'branch_list' => 'Branch List',
    'branch_name' => 'Branch Name',
    'add_branch' => 'Add Branch',
    'view_branch' => 'View Branch',
    'edit_branch' => 'Edit Branch',

];
