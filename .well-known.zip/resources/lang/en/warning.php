<?php

return [

    'warning_list' => 'Warning List',
    'warning' => 'Warning',
    'employee_name' => 'Employee Name',
    'warning_date' => 'Warning Date',
    'subject' => 'subject',
    'warning_type' => 'Warning Type',
    'warning_by' => 'Warning By',
    'add_warning' => 'Add Warning',
    'view_warning' => 'View Warning',
    'edit_warning' => 'Edit Warning',
    'description' => 'Description',

];
