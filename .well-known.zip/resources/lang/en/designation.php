<?php

return [

    'designation_list' => 'Designation List',
    'designation_name' => 'Designation Name',
    'add_designation' => 'Add Designation',
    'view_designation' => 'View Designation',
    'edit_designation' => 'Edit Designation',

];
