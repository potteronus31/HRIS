<?php 


return [
 
 'termination_list' => 'Termination List',
 'add_new_termination' => 'Add New Termination',
 'employee_name' => 'Employee Name',
 'subject' => 'Subject',
 'termination_type' => 'Termination Type',
 'notice_date' => 'Notice Date',
 'termination_date' => 'Termination Date',
 'terminated_by' => 'Terminated By',
 'termination_list' => 'Termination List',
 'view_termination' => 'View Termination',
 'employee_termination_details' => 'Employee Termination Details',
 'description' => 'Description',

];