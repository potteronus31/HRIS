<?php

return 
[
    'employee_work_hour' => 'Employee Work Hour',
    'total_working_hour' => 'Total Working Hour',
    'approve_hour' => 'Approve Hour',
    'approve_minutes' => 'Approve Minutes',

];