<?php 

return [

  'department_list' => 'Department List',
  'department_name' => 'Department Name',
  'action' => 'Action',
  'add_department' => 'Add Department',
  'view_department' => 'View Department',
  'edit_department' => 'Edit Department',

];