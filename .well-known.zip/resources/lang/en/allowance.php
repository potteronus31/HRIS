<?php 


return [
 
    'allowance_list' => 'Allowance List',
    'allowance_name' => 'Allowance Name',
    'allowance_type' => 'Allowance Type',
    'percentage_of_basic' => 'Percentage of Basic',
    'limit_per_month' => 'Limit Per Month',
    'add_allowance' => 'Add Allowance',
    'edit_allowance' => 'Edit Allowance',
    'view_allowance' => 'View Allowance',

];