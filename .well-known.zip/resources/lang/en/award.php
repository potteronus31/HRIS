<?php 

return [

    'award_list' => 'Policies and Guidelines',
    'award_name' => 'Policies and Guidelines',
    'gift_item' => 'Gift Item',
    'add_new_award' => 'Add New Policies and Guidelines',
    'edit_award' => 'Edit  Policies and Guidelines',
    'view_award' => 'View  Policies and Guidelines',
    'file_list' => 'File Attachments',
];