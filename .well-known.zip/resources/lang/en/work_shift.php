<?php 

return [

    'work_shift_list' => 'Work Shift List',
    'add_work_shift' => 'Add Work Shift',
    'work_shift_name' => 'Work Shift Name',
    'start_time' => 'Start time',
    'end_time' => 'End time',
    'late_count_time' => 'Late Count Time',
    'edit_work_shift' => 'Edit Work Shift',
    'view_work_shift' => 'View Work Shift',
];