<?php 

return [

    'employee_permanent' => 'พนักงานถาวร',
    'update_status' => 'อัปเดตสถานะ',
    'probation_period' => 'ระยะเวลาการคุมประพฤติ',
    'permanent' => 'ถาวร',


];

?>