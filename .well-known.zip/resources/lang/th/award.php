<?php 

return [

    'award_list' => 'รายชื่อรางวัล',
    'award_name' => 'ชื่อรางวัล',
    'gift_item' => 'รายการของขวัญ',
    'add_new_award' => 'เพิ่มรางวัลใหม่',
    'edi_award' => 'แก้ไขรางวัล',
    'view_award' => 'ดูรางวัล',
];