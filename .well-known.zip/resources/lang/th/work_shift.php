<?php 

return [

    'work_shift_list' => 'รายการเปลี่ยนแปลงการทำงาน',
    'add_work_shift' => 'เพิ่มกะทำงาน',
    'work_shift_name' => 'ชื่อการเปลี่ยนแปลงการทำงาน',
    'start_time' => 'เวลาเริ่มต้น',
    'end_time' => 'เวลาเริ่มต้น',
    'late_count_time' => 'เวลานับสาย',
    'edit_work_shift' => 'แก้ไขกะงาน',
    'view_work_shift' => 'ดูกะงาน',
];