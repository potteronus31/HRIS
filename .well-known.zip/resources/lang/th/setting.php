<?php 

return [
    'general_settings' => 'การตั้งค่าทั่วไป',
    'company_addrees_settings' => 'การตั้งค่าที่อยู่ บริษัท',
    'print_head_settings' => 'การตั้งค่าหัวพิมพ์',
];