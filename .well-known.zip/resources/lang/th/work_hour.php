<?php

return 
[
    'employee_work_hour' => 'ชั่วโมงทำงานของพนักงาน',
    'total_working_hour' => 'ชั่วโมงการทำงานทั้งหมด',
    'approve_hour' => 'อนุมัติชั่วโมง',
    'approve_minutes' => 'อนุมัติรายงานการประชุม',

];