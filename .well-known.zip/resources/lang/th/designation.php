<?php

return [

    'designation_list' => 'รายการกำหนด',
    'designation_name' => 'ชื่อตำแหน่ง',
    'add_designation' => 'เพิ่มการกำหนด',
    'view_designation' => 'ดูการกำหนด',
    'edit_designation' => 'แก้ไขการกำหนด',

];
