<?php

return [

    'warning_list' => 'รายการคำเตือน',
    'warning' => 'การเตือน',
    'employee_name' => 'ชื่อพนักงาน',
    'warning_date' => 'วันที่เตือน',
    'subject' => 'เรื่อง',
    'warning_type' => 'ประเภทคำเตือน',
    'warning_by' => 'เตือนโดย',
    'add_warning' => 'เพิ่มคำเตือน',
    'view_warning' => 'ดูคำเตือน',
    'edit_warning' => 'แก้ไขคำเตือน',
    'description' => 'ลักษณะ',

];
