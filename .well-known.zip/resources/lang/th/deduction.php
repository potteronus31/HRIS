<?php

return [

    'deduction_list' => 'รายการหัก',
    'deduction_name' => 'ชื่อการหัก',
    'deduction_type' => 'ประเภทการหักเงิน',
    'percentage_of_basic' => 'ร้อยละของพื้นฐาน',
    'limit_per_month' => 'จำกัด ต่อเดือน',
    'add_deduction' => 'เพิ่มการหักเงิน',
    'edit_deduction' => 'แก้ไขการหัก',
    'view_deduction' => 'ดูการหักเงิน',

];