<?php 


return [

    'holiday_list' => 'รายการวันหยุด',
    'add_holiday' => 'เพิ่มวันหยุด',
    'view_holiday' => 'มุมมองวันหยุด',
    'edit_holiday' => 'แก้ไขวันหยุด',
    'holiday_name' => 'ชื่อวันศักดิ์สิทธิ์',
    'name' => 'ชื่อ',
    'public_holiday_list' => 'รายการวันหยุดราชการ',
    'add_public_holiday' => 'เพิ่มวันหยุดนักขัตฤกษ์',
    'view_public_holiday' => 'ดูวันหยุดนักขัตฤกษ์',
    'edit_public_holiday' => 'แก้ไขวันหยุดนักขัตฤกษ์',
    'weekly_holiday_list' => 'รายการวันหยุดประจำสัปดาห์',
    'add_weekly_holiday' => 'เพิ่มวันหยุดประจำสัปดาห์',
    'view_weekly_holiday' => 'ดูวันหยุดประจำสัปดาห์',
    'edit_weekly_holiday' => 'แก้ไขวันหยุดประจำสัปดาห์',
    'start_date' => 'วันที่เริ่มต้น',
    'end_date' => 'วันที่สิ้นสุด',
    'comment' => 'คิดเห็น',

];