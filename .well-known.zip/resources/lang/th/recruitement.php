<?php 


return [
  
 
    'job_post_list' => 'รายการโพสต์งาน',
    'create_new_job_post' => 'สร้างโพสต์งานใหม่',
    'view_job_post' => 'ดูประกาศรับสมัครงาน',
    'edit_job_post' => 'แก้ไขประกาศงาน',
    'job_title' => 'ตำแหน่งงาน',
    'publish_by' => 'เผยแพร่โดย',
    'application_end_date' => 'วันที่สิ้นสุดการสมัคร',
    'description' => 'ลักษณะ',
    'job_publish_date' => 'วันที่ประกาศงาน',
    'published' => 'การตีพิมพ์',
    'unpublished' => 'ไม่ได้พิมพ์',
    'job_application' => 'ใบสมัครงาน',
    'job_candidate_list' => 'รายการผู้สมัครงาน',
    'short_listed_application' => 'แอพลิเคชันจดทะเบียนสั้น',
    'reject_application' => 'ปฏิเสธแอปพลิเคชัน',
    'job_interview' => 'สัมภาษณ์งาน',
    
    // added new 

    'job_post' => 'Job Post',
];