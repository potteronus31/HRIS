<?php 


 return [
   
     'dashboard' => 'แผงควบคุม',
     'total_employee' => 'พนักงานทั้งหมด',
     'total_department' => 'แผนก',
     'total_present' => 'นำเสนอ',
     'total_absent' => 'ขาด',
     'today_attendance' => 'วันนี้การลงทะเบียน',
     'photo' => 'ภาพถ่าย',
     'in_time' => 'ภายในเวลาที่กำหนด',
     'out_time' => 'นอกเวลา',
     'late' => 'สาย',
     'upcoming_birthday' => 'วันเกิดที่จะมาถึง',

     // completed till now 

     'recent_leave_application' => 'ใบสมัครล่าสุดลา',
     'notice_board' => 'กระดานป้ายติดประกาศ',
     


  
 ];


?>