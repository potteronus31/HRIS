<?php 


return [
 
 'termination_list' => 'รายการยกเลิก',
 'add_new_termination' => 'เพิ่มการเลิกจ้างใหม่',
 'employee_name' => 'ชื่อพนักงาน',
 'subject' => 'เรื่อง',
 'termination_type' => 'ประเภทการสิ้นสุด',
 'notice_date' => 'วันที่ประกาศ',
 'termination_date' => 'วันสิ้นสุด',
 'terminated_by' => 'สิ้นสุดโดย',
 'view_termination' => 'ดูการสิ้นสุด',
 'employee_termination_details' => 'รายละเอียดการเลิกจ้างพนักงาน',
 'description' => 'ลักษณะ',

];


