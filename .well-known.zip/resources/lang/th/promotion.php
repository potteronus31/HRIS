<?php 


return [
 
 'employee_promotion_list' => 'รายการส่งเสริมการขายของพนักงาน',
 'add_employee_promotion' => 'เพิ่มการส่งเสริมพนักงาน',
 'employee_name' => 'ชื่อพนักงาน',
 'promotion_date' => 'วันที่โปรโมชั่น',
 'promoted_department' => 'กรมส่งเสริม',
 'promoted_designation' => 'การเลื่อนตำแหน่ง',
 'promoted_paygrade' => 'เลื่อนระดับเกรดจ่าย',
 'promoted_salary' => 'เลื่อนเงินเดือน',
 'view_employee_promotion' => 'ดูโปรโมชั่นของพนักงาน',
 'current_department' => 'แผนกปัจจุบัน',
 'current_designation' => 'ตำแหน่งปัจจุบัน',
 'current_paygrade' => 'เกรดจ่ายปัจจุบัน',
 'current_salary' => 'เงินเดือนปัจจุบัน',
 'details' => 'รายละเอียด',
 
];
