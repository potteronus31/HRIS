<?php 

return [

    'payment_history' => 'ประวัติการชำระเงิน',
    'all_payment_history' => 'ประวัติการชำระเงินทั้งหมด',
    'all_payment_history' => 'ประวัติการชำระเงินทั้งหมด',
    'enter_month' => 'ป้อนเดือน',
    
    //  refere from salary_sheet

    'to_be_paid' => 'ที่จะจ่าย',
    'total' => 'ทั้งหมด',
    'my_payroll' => 'บัญชีเงินเดือนของฉัน',
];