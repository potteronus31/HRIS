<?php 

return [

    'training_type_list' => 'รายการประเภทการฝึกอบรม',
    'training_type_name' => 'ชื่อประเภทการฝึกอบรม',
    'add_training_type' => 'เพิ่มประเภทการฝึกอบรม',
    'edit_training_type' => 'แก้ไขประเภทการฝึกอบรม',
    'view_training_type' => 'ดูประเภทการฝึกอบรม',
    'employee_training_list' => 'รายการฝึกอบรมพนักงาน',
    'training_type' => 'ประเภทการฝึกอบรม',
    'subject' => 'เรื่อง',
    'training_duration' => 'ระยะเวลาการฝึกอบรม',
    'add_employee_training' => 'เพิ่มการฝึกอบรมพนักงาน',
    'edit_employee_training' => 'แก้ไขการฝึกอบรมพนักงาน',
    'view_employee_training' => 'ดูการฝึกอบรมพนักงาน',
    'certificate' => 'ใบรับรอง',
    'description' => 'ลักษณะ',
    'employee_training_report' => 'รายงานการฝึกอบรมพนักงาน',

];