<?php

// role and premission related 

return [
 
    'add_role' => 'เพิ่มบทบาท',
    'edit_role' => 'แก้ไขบทบาท',
    'role_list' => 'รายการบทบาท',
    'name' => 'ชื่อ',
    'view_role' => 'ดูบทบาท',
    'role_name' => 'ชื่อบทบาท',
    'add_role_permission' => 'เพิ่มการอนุญาตบทบาท',
    'role_permission' => 'การอนุญาตบทบาท',
    'page_permission' => 'การอนุญาตหน้า',
    'select_all' => 'เลือกทั้งหมด',
    'user_role' => 'บทบาทของผู้ใช้',

];