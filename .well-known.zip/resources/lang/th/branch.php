<?php

return [

    'branch_list' => 'รายชื่อสาขา',
    'branch_name' => 'ชื่อสาขา',
    'add_branch' => 'เพิ่มสาขา',
    'view_branch' => 'ดูสาขา',
    'edit_branch' => 'แก้ไขสาขา',

];
