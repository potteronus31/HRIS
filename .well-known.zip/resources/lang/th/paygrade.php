<?php 

return [

    'pay_grade_list' => 'จ่ายรายการเกรด',
    'pay_grade_name' => 'จ่ายชื่อเกรด',
    'gross_salary' => 'เงินเดือนขั้นต้น',
    'percentage_of_basic' => 'ร้อยละของพื้นฐาน',
    'percentage_of_basic' => 'ร้อยละของพื้นฐาน',
    'basic_salary' => 'เงินเดือนทั่วไป',
    'over_time_rate' => 'อัตราการทำงานล่วงเวลา',
    'add_pay_grade' => 'เพิ่มเกรดจ่าย',
    'edit_pay_grade' => 'แก้ไขเกรดการจ่าย',
    'view_pay_grade' => 'ดูเกรดจ่าย',
    'allowance' => 'เบี้ยเลี้ยง',
    'deduction' => 'การหัก',
    'per_hour' => 'ต่อชั่วโมง',
    'hourly_pay_grade_list' => 'รายการเกรดจ่ายรายชั่วโมง',
    'hourly_grade' => 'ระดับรายชั่วโมง',
    'hourly_rate' => 'อัตราชั่วโมง',
    'add_hourly_pay_grade' => 'เพิ่มเกรดการจ่ายรายชั่วโมง',
    'edit_hourly_pay_grade' => 'แก้ไขเกรดการจ่ายรายชั่วโมง',
    'view_hourly_pay_grade' => 'ดูเกรดการจ่ายรายชั่วโมง',
    'hourly_pa_grade_name' => 'ชื่อเกรดจ่ายรายชั่วโมง',

    

];