<?php 

return [
 
    'bonus_setting' => 'การตั้งค่าโบนัส',
    'festival_name' => 'ชื่อเทศกาล',
    'percentage_of_bonus' => 'ร้อยละของโบนัส',
    'add_new_bonus' => 'เพิ่มโบนัสใหม่',
    'edit_bonus' => 'แก้ไขโบนัส',
    'view_bonus' => 'ดูโบนัส',
    'bonus_type' => 'ประเภทโบนัส',
    'tax' => 'ภาษี',
    'bonus_amount' => 'จำนวนโบนัส',
    'generate_bonus' => 'สร้างโบนัส',
    'view_bonus_list' => 'ดูรายการโบนัส',
    'view_bonus_list' => 'ดูรายการโบนัส',

    // newly added 

    'bonus_list' => 'รายการโบนัส',
    'net_bonus' => 'โบนัสสุทธิ',
    'total_bonus' => 'โบนัสทั้งหมด',

];