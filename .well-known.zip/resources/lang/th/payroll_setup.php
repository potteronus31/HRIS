<?php 


return [
 
    'tax_rule_setup' => 'การตั้งค่ากฎภาษี',
    'rate_of_income_tax' => 'อัตราภาษี',
    'total_income' => 'รายได้ทั้งหมด',
    'tax_rules' => 'กฎภาษี',
    'male' => 'ชาย',
    'female' => 'หญิง',
    'remaining_total_income' => 'รายได้รวมที่เหลืออยู่',
    'remaining_taxable_amount' => 'จำนวนเงินที่ต้องเสียภาษีที่เหลืออยู่',
    'first' => 'เป็นครั้งแรก',
    'next' => 'ต่อไป',
    'salary_deduction_for_late_attendance' => 'การหักเงินเดือนสำหรับการเข้างานล่าช้า',
    'rules_for_salary_deduction' => ' กฎการหักเงินเดือน',
    'for_days' => ' เป็นเวลาหลายวัน',
    'day_oF_salary_deduction' => 'วันหักเงินเดือน',

        // newly added 

        'tax_rate' => 'อัตราภาษี',
        'taxable_amount' => 'จำนวนเงินที่ต้องเสียภาษี',

];