<?php 

return [

  'department_list' => 'รายชื่อกรม',
  'department_name' => 'ชื่อห้างสรรพสินค้า',
  'action' => 'การกระทำ',
  'add_department' => 'เพิ่มแผนก',
  'view_department' => 'ดูแผนก',
  'edit_department' => 'แก้ไขแผนก',

];