<?php 

return [

    'notice_list' => 'รายการประกาศ',
    'notice_name' => 'แจ้งให้ทราบชื่อ',
    'title' => 'หัวข้อ',
    'publish_date' => 'วันที่เผยแพร่',
    'published_by' => 'เผยเเพร่โดย',
    'attach_file' => 'แนบไฟล์',
    'description' => 'ลักษณะ',
    'add_new_notice' => 'เพิ่มประกาศใหม่',
    'edi_notice' => 'แก้ไขประกาศ',
    'view_notice' => 'ดูประกาศ',
];