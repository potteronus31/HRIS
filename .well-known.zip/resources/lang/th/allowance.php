<?php 


return [
 
    'allowance_list' => 'รายการค่าเผื่อ',
    'allowance_name' => 'ชื่อค่าเผื่อ',
    'allowance_type' => 'ประเภทเบี้ยเลี้ยง',
    'percentage_of_basic' => 'ร้อยละของพื้นฐาน',
    'limit_per_month' => 'จำกัด ต่อเดือน',
    'add_allowance' => 'เพิ่มค่าเผื่อ',
    'edit_allowance' => 'แก้ไขค่าเผื่อ',
    'view_allowance' => 'ดูค่าเผื่อ',

];